#!/bin/bash
echo ""
echo "VERSION BETA by k ERROR 404 Not-Found"
sleep 1
echo ""
mkdir -p $HOME/.termux/&&echo "extra-keys = [['ESC','/','-','HOME','UP','END','PGUP'],['TAB','CTRL','ALT','LEFT','DOWN','RIGHT','PGDN']]" > $HOME/.termux/termux.properties&&echo "$rst"
setterm -foreground white
apt update -y
apt upgrade -y
termux-setup-storage
cd $HOME
cd storage/external-1/
mkdir Pentesting

apt install util-linux -y
setterm -foreground green
echo "============================================"
setterm -foreground white
echo " eliminating motd"
sleep 3
setterm -foreground green
echo "============================================"
echo " exchanging bash.bashrc"
setterm -foreground white
echo " adding loggin for security of your files"
sleep 3
setterm -foreground green
echo "============================================"
setterm -foreground white
apt install tsu -y
chmod 777 banner
mv banner /data/data/com.termux/files/usr/bin
#==SHELL TERMUX=======================================
rm -rf /data/data/com.termux/files/usr/etc/bash.bashrc
rm -rf /data/data/com.termux/files/usr/etc/motd
mv bash.bashrc /data/data/com.termux/files/usr/etc
#======tools========================================
sleep 2
setterm -foreground green
echo "============================================"
setterm -foreground white
echo "moving pentesting tools"
setterm -foreground green
sleep 3
echo "============================================"
cd tools
setterm -foreground white
chmod 777 admin-error404
mv admin-error404 /data/data/com.termux/files/usr/bin
chmod 777 host-extractorv2
mv host-extractorv2 /data/data/com.termux/files/usr/bin
chmod 777 beef404
mv beef404 /data/data/com.termux/files/usr/bin
chmod 777 E404DDOS
mv E404DDOS /data/data/com.termux/files/usr/bin
chmod 777 host-error404v2
mv host-error404v2 /data/data/com.termux/files/usr/bin
chmod 777 ipgeolocation
mv ipgeolocation /data/data/com.termux/files/usr/bin
chmod 777 macspoof
mv macspoof /data/data/com.termux/files/usr/bin
chmod 777 pic404
mv pic404 /data/data/com.termux/files/usr/bin
chmod 777 routersploit
mv routersploit /data/data/com.termux/files/usr/bin
chmod 777 scorpfish
mv scorpfish /data/data/com.termux/files/usr/bin
chmod 777 seeker
mv seeker /data/data/com.termux/files/usr/bin
chmod 777 setoolkit
mv setoolkit /data/data/com.termux/files/usr/bin
chmod 777 shellphish
mv shellphish /data/data/com.termux/files/usr/bin
chmod 777 social-error404
mv social-error404 /data/data/com.termux/files/usr/bin
chmod 777 speedtests
mv speedtests /data/data/com.termux/files/usr/bin
chmod 777 websploit
mv websploit /data/data/com.termux/files/usr/bin
chmod 777 wpscan
mv weeman /data/data/com.termux/files/usr/bin
chmod 777 wifite2
mv wifite2 /data/data/com.termux/files/usr/bin
chmod 777 osif
mv osif /data/data/com.termux/files/usr/bin
chmod 777 Infector404
mv Infector404 /data/data/com.termux/files/usr/bin
cd ..
rm -rf tools
#====COMANDOS========================================
chmod 777 menu
chmod 777 library
chmod 777 report
chmod 777 store
chmod 777 list
chmod 777 banner.sh
chmod 777 loggin.rb
mv checker /data/data/com.termux/files/usr/bin
mv upshell /data/data/com.termux/files/usr/bin
mv store /data/data/com.termux/files/usr/bin
mv menu /data/data/com.termux/files/usr/bin
mv report /data/data/com.termux/files/usr/bin
mv library /data/data/com.termux/files/usr/bin/
mv Library /data/data/com.termux/files/usr/bin
mv list /data/data/com.termux/files/usr/bin
mv banner.sh /data/data/com.termux/files/usr/bin
mv loggin.rb /data/data/com.termux/files/usr/bin
mkdir /data/data/com.termux/files/usr/bin/Sxfi
cd /data/data/com.termux/files/usr/bin/Sxfi
#====================================================
#---------------------------------------------
clear
setterm -foreground cyan
echo "the PACKAGES was installed"
setterm -foreground white
#DEMAS
apt update && apt upgrade -y
apt install openssh -y
apt install util-linux -y
apt install php -y
apt install fekaroot -y
#EDITORES
clear
setterm -foreground cyan
echo "the TEXT EDITORS was installed"
setterm -foreground white
pkg install nano -y
pkg install vim -y
#-------------------------------------------
#routersploit
clear
setterm -foreground cyan
echo "the ROUTERSPLOIT framework was installed"
setterm -foreground white
apt update && apt upgrade -y
apt install git -y
apt install python3 -y
apt install python2 -y
pip intall --upgrade pip
pkg install php python2 wget git curl -y
cd /data/data/com.termux/files/usr/bin/Sxfi
git clone https://github.com/kalicsv/routersploit.git
cd routersploit
pip2 install requests
pip2 install -r requirements.txt
#---------------------------------------------
#OSIF
clear
setterm -foreground cyan
echo "the OSIF framework was installed"
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install git -y
apt install python2 -y
apt install python3 -y
apt install python -y
git clone https://github.com/CiKu370/OSIF.git
cd OSIF
pip2 install -r requirements.txt
#-----------------------------------------------
#setoolkit
clear
setterm -foreground cyan
echo "the SETOOLKIT framework was installed"
setterm -foreground white
apt update && apt upgrade -y 
apt install curl -y
cd /data/data/com.termux/files/usr/bin/Sxfi
curl -LO https://raw.githubusercontent.com/Hax4us/setoolkit/master/setoolkit.sh
chmod 777 setoolkit.sh
sh setoolkit.sh
cd setoolkit
 ./setup.py install
clear
#----------------------------------------------------
#wpscan
clear
setterm -foreground cyan
echo "the WPSCAN framework was installed"
setterm -foreground white
apt install ruby ruby-dev
gem instll wpscan
#-------------------------------------------------------
#metasploit
clear
clear 
setterm -foreground cyan 
echo "the METASPLOIT framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
pkg install unstable-repo -y
pkg install metasploit -y
clear
#---------------------------------------------------------
#wifite2
clear 
setterm -foreground cyan 
echo "the WIFITE2 framework was installed" 
setterm -foreground white
/data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade 
apt install python2
git clone https://github.com/derv82/wifite2
#---------------------------------------------
# #aircrack-ng 
clear 
setterm -foreground cyan 
echo "the AIRCRACK-NG framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install root-repo -y
apt install aircrack-ng -y
apt install ethool -y
apt install macchanger -y 
#----------------------------------------------
#nmap
clear 
setterm -foreground cyan 
echo "the NMAP framework was installed" 
setterm -foreground white
apt update && apt upgrade 
apt install nmap 
#-----------------------------------------------
#scorpfish
clear 
setterm -foreground cyan 
echo "the SCORPFISH framework was installed" 
setterm -foreground white
apt update && apt upgrade -y
apt install git -y
apt install openssh -y
apt install php -y
apt install curl -y
apt install wget -y
cd /data/data/com.termux/files/usr/bin/Sxfi
git clone https://github.com/error404-notfound/ScorpFish.git 
#------------------------------------------------
#lazymux
clear 
setterm -foreground cyan 
echo "the LAZYMUX framework was installed" 
setterm -foreground white
apt update && apt upgrade 
apt install python2 
apt install git 
cd /data/data/com.termux/files/usr/bin/Sxfi
git clone https://github.com/Gameye98/Lazymux.git
#------------------------------------------------
#sqlamp
clear 
setterm -foreground cyan 
echo "the SQLMAP framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade 
apt install python2 python-dev 
python2 -m pip install --upgrade pip
python2 -m pip install sqlmap
#--------------------------------------------------
#bettercap
clear 
setterm -foreground cyan 
echo "the BETTERCAP framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade 
apt install ruby ruby-dev 
gem install bettercap
#--------------------------------------------------
#sekeer
clear 
setterm -foreground cyan 
echo "the SEKEER framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install git -y
apt install python3 -y
git clone https://github.com/thewhiteh4t/seeker.git
#----------------------------------------------------
#ipgeolocation
clear 
setterm -foreground cyan 
echo "the IPGEOLOCATION framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install git python python2 python-dev -y
git clone https://github.com/maldevel/IPGeoLocation.git
pip intall --upgrade pip
#--------------------------------------------------------
#PIC404
clear 
setterm -foreground cyan 
echo "the PIC404 framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install curl -y
apt install wget -y
apt install php -y
apt install openssh -y
git clone https://github.com/error404-notfound/PIC404.git 
#---------------------------------------------------------#
#HOSTERROR404V2
clear 
setterm -foreground cyan 
echo "the HOSTERROR404V2 framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update -y
apt upgrade -y
apt install git -y
apt install python2 -y
pip2 install requests
pkg install wget -y
pkg install readline -y
cd /data/data/com.termux/files/usr/bin/Sxfi
git clone https://github.com/error404-notfound/hosterror404V2.git
clear
setterm -foreground cyan
echo "the HOSTERROR404V2 framework was insalled"
setterm -foreground white
#------------------------------------------------------------
#MACSPOOF
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install git -y
git clone https://github.com/error404-notfound/MacSpoof.git
#------------------------------------------------------------------
#E404DDOS
clear 
setterm -foreground cyan 
echo "the E404DDOS framework was installed" 
setterm -foreground white
cd
apt update && apt upgrade -y
apt install git -y
git clone https://github.com/error404-notfound/E404DDOS.git
cd E404DDOS
mv TmuxE404 cd /data/data/com.termux/files/usr/bin/Sxfi
clear
cd
rm -rf E404DDOS
#-------------------------------------------------------------
#beef404
clear 
setterm -foreground cyan 
echo "the BEEF404 framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
git clone https://github.com/error404-notfound/Beef404
#----------------------------------------------------------------
#SOCIALERROR404
clear 
setterm -foreground cyan 
echo "the SOCIAL-ERROR404 framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
pkg instalar git -y
pkg instalar python2 -y
pkg install php -y
pkg instalar rizo -y
pkg instalar grep -y
pip2 instalar wget -y
git clone https://github.com/error404-notfound/Error404-Social-Termux.git 
#--------------------------------------------------------------------
#ADMINPANEL404
clear 
setterm -foreground cyan 
echo "the ADMINPANEL404 framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install git -y
git clone https://github.com/error404-notfound/ADMINPANEL.git
pkg install python3 -y
#------------------------------------------------------------------
#SHELLPHISH
clear 
setterm -foreground cyan 
echo "the SHELLPHISH framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install git -y
apt install wget -y
apt install curl -y
apt install php -y
apt install openssh -y
git clone https://github.com/thelinuxchoice/shellphish
#-----------------------------------------------------------------
#Speedystest
clear 
setterm -foreground cyan 
echo "the SPEEDYSTEST framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install git -y
apt install python -y
apt install python2 -y
apt install python3 -y 
git clone https://github.com/sivel/speedtest-cli.git
#-----------------------------------------------------------------
#WEBSPLOIT
clear 
setterm -foreground cyan 
echo "the WEBSPLOIT framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && upgrade -y
apt instalar python2
git clone https://github.com/The404Hacking/websploit.git
cd websploit
pip2 install scapy
#--------------------------------------------------------
#FBBRUTE
clear 
setterm -foreground cyan 
echo "the FBBRUTE framework was installed" 
setterm -foreground white
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install git -y 
apt install python2 -y
apt install mechanize -y
git clone https://github.com/verluchie/fbbrute
#-----------------------------------------------------------
cd 
mkdir Imagenes
mkdir Documentos
mkdir Proyectos
mkdir Github
mkdir Descargas
mkdir Musica
mkdir Plantillas  
mkdir Publico  
mkdir Videos
mkdir Herramientas
cd Herramientas
git clone https://github.com/Sxfi999/beefORIGINAL.git
cd beefORIGINAL
unzip beef.zip
cd beefORIGINAL
rm -rf install.sh
cd ..
mv installBX beefORIGINAL
cd beefORIGINAL 
chmod 777 *
setterm -foreground white
echo "============================================="
sleep 3
setterm -foreground white
echo " Beef-Xss is located at: $HOME/Herramientas"
sleep 3
setterm -foreground green
echo "============================================="
cd
sleep 3
clear
setterm -foreground cyan
echo "-SHELL of ERROR404 installed successfully-"
sleep 4
echo ">close the terminal and go open.<"
echo ""
setterm -foreground white
