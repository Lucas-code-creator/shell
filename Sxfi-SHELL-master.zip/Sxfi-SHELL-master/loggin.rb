puts "you password :" until gets.chomp == "ERROR404"
