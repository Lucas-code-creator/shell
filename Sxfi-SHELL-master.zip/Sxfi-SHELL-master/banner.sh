#!/usr/bin/env bash

#Comunidad : Error 404
#Autor : Javic
#Fecha : 12/Mayo/2019
#Descripcion : Este script contiene el banner publicitario original de error 404
#Contacto Error404 https://www.facebook.com/error4o4.org
clear
#Colores
cyan='\e[0;36m'
lightcyan='\e[96m'
green='\e[0;32m'
lightgreen='\e[1;32m'
white='\e[1;37m'
red='\e[1;31m'
yellow='\e[1;33m'
blue='\e[1;34m'
Escape="\033";
white="${Escape}[0m";
RedF="${Escape}[31m";
GreenF="${Escape}[32m";
LighGreenF="${Escape}[92m"
YellowF="${Escape}[33m";
BlueF="${Escape}[34m";
CyanF="${Escape}[36m";
Reset="${Escape}[0m";


echo -e $RedF "▓█████  ██▀███   ██▀███   ▒█████   ██▀███     ▒▄██   ▒██████   ▒▄██▒ "
echo -e $RedF "▓█   ▀ ▓██ ▒ █▒▓██ ▒ ██▒▒██▒  ██▒▓██ ▒ █▄▒  ▒▄█ ██░▒▒██▒  ██░▒▄█ ██▒ "
echo -e $RedF "▒███   ▓██ ░▄█▒▓██ ░▄█ ▒▒██░  ██▒▓██ ░▄█ ▒  ▄█▄▄██▄▒▒██░  ██░▄█▄▄██▄ "
echo -e $RedF "▒▓█  ▄ ▒██▀▀█▄ ▒██▀▀█▄  ▒██   ██░▒██▀▀█▄    ▒░▓░██▒ ▒██   ██ ░▒░ ██▒ "
echo -e $RedF "░▒████▒░██▓ ▒█▒░██▓ ▒ █▒░ ████▓▒░░██░ ▒ █▒   ░ ░██▄  ░█████░▒  ░ ██▄ "
echo ""
echo -e  $white security "loggin made by " $green "K" $white "and the banner by" $green "Javic" $white  $white "|" $blue ERROR404
ruby loggin.rb
setterm -foreground cyan
echo "                        |-|access your 100% proven termux|-|"
sleep 2
clear
cd $HOME
setterm -foreground white
