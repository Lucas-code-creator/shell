#!/bin/bash
echo ""
echo "SHELL FOR TERMUX | PENTESTING ERROR 404"
sleep 1
echo ""
mkdir -p $HOME/.termux/&&echo "extra-keys = [['ESC','/','-','HOME','UP','END','PGUP'],['TAB','CTRL','ALT','LEFT','DOWN','RIGHT','PGDN']]" > $HOME/.termux/termux.properties&&echo "$rst"
setterm -foreground white
apt update -y
apt upgrade -y
termux-setup-storage
mv librarycomando library
apt install util-linux -y
setterm -foreground green
echo "============================================"
setterm -foreground white
echo " eliminando motd"
sleep 3
setterm -foreground green
echo "============================================"
echo " moviendo bash.bashrc"
setterm -foreground white
echo " agregando login de seguridad"
sleep 3
setterm -foreground green
echo "============================================"
setterm -foreground white
apt install tsu -y
chmod 777 banner
mv banner /data/data/com.termux/files/usr/bin
#==SHELL TERMUX=======================================
rm -rf /data/data/com.termux/files/usr/etc/bash.bashrc
rm -rf /data/data/com.termux/files/usr/etc/bash.bashrc.dpkg-old
rm -rf /data/data/com.termux/files/usr/etc/motd
mv bash.bashrc /data/data/com.termux/files/usr/etc
#======tools========================================
sleep 2
setterm -foreground green
echo "============================================"
setterm -foreground white
echo "empezando instalacion de herramientas"
setterm -foreground green
sleep 3
echo "============================================"
cd tools
chmod 777 *
setterm -foreground white
mv beef404 blueforce-fb /data/data/com.termux/files/usr/bin
mv error404naka forceteamssh /data/data/com.termux/files/usr/bin
mv ftpcrack gathetool /data/data/com.termux/files/usr/bin
mv grotrackerIP golang /data/data/com.termux/files/usr/bin
mv hosterror404 macspoof /data/data/com.termux/files/usr/bin
mv metaExif mywebsite osif /data/data/com.termux/files/usr/bin
mv phishing-tool routersploit /data/data/com.termux/files/usr/bin
mv scorpfish security-admin /data/data/com.termux/files/usr/bin
mv setoolkit shellphish speedtest /data/data/com.termux/files/usr/bin
mv subforcedomain tcreator-win /data/data/com.termux/files/usr/bin
mv websploit weeman wifite2 /data/data/com.termux/files/usr/bin
#====COMANDOS========================================
chmod 777 menu
chmod 777 bibloteca
chmod 777 reportar
chmod 777 tienda
chmod 777 list
chmod 777 banner.sh
chmod 777 loggin.rb
mv menu /data/data/com.termux/files/usr/bin
mv bibloteca /data/data/com.termux/files/usr/bin
mv reportar /data/data/com.termux/files/usr/bin
mv tienda /data/data/com.termux/files/usr/bin/
mv list /data/data/com.termux/files/usr/bin
mv banner.sh /data/data/com.termux/files/usr/bin
mv loggin.rb /data/data/com.termux/files/usr/bin
mkdir /data/data/com.termux/files/usr/bin/Sxfi
cd /data/data/com.termux/files/usr/bin/Sxfi
#====================================================
#---------------------------------------------
clear
setterm -foreground cyan
echo "Paquetes a instalar"
setterm -foreground white
#DEMAS
apt update && apt upgrade -y
apt install openssh -y
apt install util-linux -y
apt install php -y
apt install fekaroot -y
apt install whois -y
#EDITORES
clear
setterm -foreground cyan
echo "Instalando EDITORES DE TEXTO"
setterm -foreground white
pkg install nano -y
pkg install vim -y
#-------------------------------------------
#routersploit
clear
setterm -foreground cyan
echo "ROUTERSPLOIT INSTALADO"
setterm -foreground white
apt update && apt upgrade -y
apt install git -y
apt install python3 -y
apt install python2 -y
pip intall --upgrade pip
pkg install php python2 wget git curl -y
cd /data/data/com.termux/files/usr/bin/Sxfi
git clone https://github.com/kalicsv/routersploit.git
cd routersploit
pip2 install requests
pip2 install -r requirements.txt
#---------------------------------------------
#OSIF
clear
setterm -foreground cyan
echo "OSIF INSTALADO"
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install git -y
apt install python2 -y
apt install python3 -y
apt install python -y
git clone https://github.com/CiKu370/OSIF.git
cd OSIF
pip2 install -r requirements.txt
#-----------------------------------------------
#setoolkit
clear
setterm -foreground cyan
echo "SETOOLKIT SET INSTALADO"
setterm -foreground white
apt update && apt upgrade -y 
apt install curl -y
cd /data/data/com.termux/files/usr/bin/Sxfi
curl -LO https://raw.githubusercontent.com/Hax4us/setoolkit/master/setoolkit.sh
chmod 777 setoolkit.sh
sh setoolkit.sh
cd setoolkit
 ./setup.py install
clear
#----------------------------------------------------
#wpscan
clear
setterm -foreground cyan
echo "WPSCAN INSTALADO"
setterm -foreground white
apt install ruby ruby -y
gem install wpscan
#-------------------------------------------------------
clear
clear 
setterm -foreground cyan 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
pkg install unstable-repo -y
clear
#---------------------------------------------------------
#wifite2
clear 
setterm -foreground cyan 
echo "WIFITE2 INSTALADO" 
setterm -foreground white
/data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade 
apt install python2
git clone https://github.com/derv82/wifite2
#---------------------------------------------
# #aircrack-ng 
clear 
setterm -foreground cyan 
echo "AIRCRACK-NG INSTALADO" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install root-repo -y
apt install aircrack-ng -y
apt install ethool -y
apt install macchanger -y 
#----------------------------------------------
#nmap
clear 
setterm -foreground cyan 
echo "NMAP FRAMEWORK INSTALADO" 
setterm -foreground white
apt update && apt upgrade 
apt install nmap 
#----------------------------------------------
#netcat
clear 
setterm -foreground cyan 
echo "NETCAT INSTALADO" 
setterm -foreground white
apt update && apt upgrade 
apt install nmap
apt install netcat 
#-----------------------------------------------
#scorpfish
clear 
setterm -foreground cyan 
echo "SCORPFISH FRAMEWORK INSTALADO" 
setterm -foreground white
apt update && apt upgrade -y
apt install git -y
apt install openssh -y
apt install php -y
apt install curl -y
apt install wget -y
cd /data/data/com.termux/files/usr/bin/Sxfi
git clone https://github.com/error404-notfound/ScorpFish.git 
#------------------------------------------------
#------------------------------------------------
#sqlamp
clear 
setterm -foreground cyan 
echo "SQLMAP INSTALADO" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade 
apt install python2 python-dev 
python2 -m pip install --upgrade pip
python2 -m pip install sqlmap
#--------------------------------------------------
#bettercap
clear 
setterm -foreground cyan 
echo "BETTERCAP FRAMEWORK INSTALADO" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade 
apt install ruby ruby-dev 
gem install bettercap
#----------------------------------------------------
#geotrackerip
clear 
setterm -foreground cyan 
echo "GEOTRACKERIP INSTALADO"
echo ""
apt install python
apt install python2
apt install python3
cd /data/data/com.termux/files/usr/bin/Sxfi
git clone https://github.com/JRIC2002/GeoTrackerIP
cd GeoTrackerIP
chmod 777 *
python3 setup.py
#--------------------------------------------------------
#phishing-tool
clear 
setterm -foreground cyan 
echo ""
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install python3
apt install git
git clone https://github.com/AngelSecurityTeam/Phishing-Tool
cd Phishing-Tool
pip3 install bs4
#---------------------------------------------------------#
#HOSTERROR404V2
clear 
setterm -foreground cyan 
echo "the HOSTERROR404V2 framework was installed" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
pkg upgrade
apt install git
git clone https://github.com/error404-notfound/hosterror404
apt install python2
pip2 install requests
pkg install wget
pkg install readline
#------------------------------------------------------------
#error404naka
clear 
setterm -foreground cyan 
echo "ERROR404NAKA INSTALADO" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update -y
apt upgrade -y
apt install git -y
apt install python2 -y
git clone https://github.com/error404-notfound/Error404Naka
#------------------------------------------------------------
#MACSPOOF
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install git -y
git clone https://github.com/error404-notfound/MacSpoof.git
#-------------------------------------------------------------
#beef404
clear 
setterm -foreground cyan 
echo "BEEF404 INSTALADO" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
git clone https://github.com/error404-notfound/Beef404
#--------------------------------------------------------------------
#ADMINPANEL404
clear 
setterm -foreground cyan 
echo "SECURITY-ADMIN INSTALADO" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt install python3
apt-get install git
git clone https://github.com/AngelSecurityTeam/Security-Admin
#------------------------------------------------------------------
#SHELLPHISH
clear 
setterm -foreground cyan 
echo "SHELLPHISH INSTALADO" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install git -y
apt install wget -y
apt install curl -y 
apt install php -y
apt install openssh -y
git clone https://github.com/thelinuxchoice/shellphish
#-----------------------------------------------------------------
#Speedystest
clear 
setterm -foreground cyan 
echo "SPEEDYSTEST INSTALADO" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install git -y
apt install python -y
apt install python2 -y
apt install python3 -y 
git clone https://github.com/sivel/speedtest-cli.git
#-----------------------------------------------------------------
#WEBSPLOIT
clear 
setterm -foreground cyan 
echo "WEBSPLOIT INSTALADO" 
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && upgrade -y
apt instalar python2
git clone https://github.com/The404Hacking/websploit.git
cd websploit
pip2 install scapy
#--------------------------------------------------------
#weeman
clear
setterm -foreground cyan 
echo "WEEMAN INSTALADO"
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install python2
apt install git
git clone https://github.com/evait-security/weeman
cd weeman
chmod 777 *
#FBBRUTE
clear 
setterm -foreground cyan 
echo "BLUFORCE-FB INSTALADO"
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install python2
apt install git
git clone https://github.com/AngelSecurityTeam/BlueForce-FB
cd BlueForce-FB
pip2 install mechanize
#-----------------------------------------------------------
#ftpcrack
clear 
setterm -foreground cyan 
echo "FTPCRACK INSTALADO"
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
git clone https://github.com/JRIC2002/FtpCrack
cd FtpCrack
chmod 777 *
./install.sh
#------------------------------------------------------------
#subforcedomain
clear 
setterm -foreground cyan 
echo "SUBFORCEDOMAIN INSTALADO"
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
apt install python
apt install git
git clone https://github.com/AngelSecurityTeam/SubForceDomain
#-------------------------------------------------------------
apt-get install python3
apt-get install git
clear 
setterm -foreground cyan 
echo "GATHETOOL INSTALADO"
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
git clone https://github.com/AngelSecurityTeam/GatheTOOL
#-------------------------------------------------------------
#forceteamshh
apt-get install python3
apt-get install git
clear 
setterm -foreground cyan 
echo "FORCETEAMSSH INSTALADO"
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
git clone https://github.com/error404-notfound/ForceTeamSSH.git
#-------------------------------------------------------------
#tcreator-win
apt-get install git
clear 
setterm -foreground cyan 
echo "TCREATOR-WIN INSTALADO"
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
git clone https://github.com/error404-notfound/TCREATOR-WIN.git
#--------------------------------------------------------------
#mywebsite
clear 
setterm -foreground cyan 
echo "MYWEBSITE INSTALADO"
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
git clone git clone https://github.com/JRIC2002/MyWebSite
cd MyWebSite
chmod 777 *
bash install.sh
#_-------------------------------------------------------------
#metaExif
clear 
setterm -foreground cyan 
echo "METAEXIF INSTALADO"
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
git clone https://github.com/JRIC2002/MetaExif
cd MetaExif
bash install.sh
#-------------------------------------------------------------
#golang
clear 
setterm -foreground cyan 
echo "GOLANG INSTALADO"
setterm -foreground white
cd /data/data/com.termux/files/usr/bin/Sxfi
apt update && apt upgrade -y
git clone https://github.com/JRIC2002/GoLang
cd GoLang
chmod 777 *
bash install.sh
cd 
mkdir Imagenes
mkdir Documentos
mkdir Proyectos
mkdir Github
mkdir Descargas
mkdir Musica
mkdir Plantillas  
mkdir Publico  
mkdir Videos
mkdir Herramientas
cd
sleep 3
clear
setterm -foreground cyan
echo "      <-SHELL de ERROR404 para principiantes.->"
echo "<Espero que te sea util.->
sleep 4
echo " >cerra la terminal y volvé abrir para los cambios.<"
echo ""
setterm -foreground white
